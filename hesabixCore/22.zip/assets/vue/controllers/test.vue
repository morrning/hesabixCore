<template>
  <div>
    This is test component
  </div>
</template>

<script>

export default {
  name: "test",
  data: ()=>{return {
    searchValue: '',
  }},
  mounted() {
  }
}
</script>

<style scoped>

</style>